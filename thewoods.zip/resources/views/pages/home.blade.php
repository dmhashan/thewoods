@extends('layouts.home')
@section('title', 'Home')
@section('content')
    
    
    
@stop
