@extends('layouts.default')
@section('content')
    
    <div class="inner">
        <div class="container">
            <div class="row">
                <div class="table-cell col-md-7">
                    <h2 class="uppercase">
                        Waste no more time!
                    </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit scelerisque.</p>
                </div>
                <div class="table-cell col-md-5 text-right">
                    <a href="#" class="btn-purchase btn btn-primary btn-lg large-padding">Purchase Corpress</a>
                    <a href="#" class="btn btn-border btn-lg large-padding">Tell Me More</a>
                </div>
            </div>

        </div>
    </div>
    
@stop
