<!-- START REVOLUTION SLIDER 2.3.91 -->
<div class="rev-slider-container animated" data-fx="fadeInUp">
<div id="rev1" class="rev-slider" >
<ul>
    <?php
    foreach (Config::get('companycarousel.slides') as $key => $value) {
    ?>
        <li 
            data-transition="<?php echo e($value['data']['transition']); ?>"
            data-slotamount="<?php echo e($value['data']['slotamount']); ?>"
            data-masterspeed="<?php echo e($value['data']['masterspeed']); ?>" >
                <img 
                    src="<?php echo e($value['src']); ?>"
                    alt="<?php echo e($value['alt']); ?>"
                    data-bgposition="<?php echo e($value['data']['bgposition']); ?>"
                    data-duration="<?php echo e($value['data']['duration']); ?>"
                    data-ease="<?php echo e($value['data']['ease']); ?>"
                    data-bgfit="<?php echo e($value['data']['bgfit']); ?>"
                    data-bgfitend="<?php echo e($value['data']['bgfitend']); ?>"
                    data-bgpositionend="<?php echo e($value['data']['bgpositionend']); ?>" >
        </li>
    <?php
    }
    ?>

</ul>
<div class="tp-bannertimer"></div>
</div>
</div>
