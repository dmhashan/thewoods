<!-- scripts bellow -->

<script src="<?php echo e(URL::asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/corpress.min.js')); ?>"></script>
<!-- IE -->
<script src="<?php echo e(URL::asset('assets/js/modernizr.custom.js')); ?>"></script>





<!-- Revolution Slider -->
<script src="<?php echo e(URL::asset('assets/plugins/revslider/js/jquery.themepunch.revolution.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/revslider/js/jquery.themepunch.plugins.min.js')); ?>"></script>

<!-- Flexslider -->
<script src="<?php echo e(URL::asset('assets/plugins/flexslider/jquery.flexslider-min.js')); ?>"></script>



<!-- Contact form validation -->
<script src="<?php echo e(URL::asset('assets/form/js/contact-form.js')); ?>"></script>

<!-- our main JS file -->
<script src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script>

<!-- end scripts -->