<!-- scripts bellow -->

<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/corpress.min.js"></script>
<!-- IE -->
<script src="assets/js/modernizr.custom.js"></script>





<!-- Revolution Slider -->
<script src="assets/plugins/revslider/js/jquery.themepunch.revolution.min.js"></script>
<script src="assets/plugins/revslider/js/jquery.themepunch.plugins.min.js"></script>

<!-- Flexslider -->
<script src="assets/plugins/flexslider/jquery.flexslider-min.js"></script>



<!-- Contact form validation -->
<script src="assets/form/js/contact-form.js"></script>

<!-- our main JS file -->
<script src="assets/js/main.js"></script>

<!-- end scripts -->